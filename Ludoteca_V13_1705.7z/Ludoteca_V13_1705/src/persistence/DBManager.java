/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

import business.Artista;
import business.Autor;
import business.Categoria;
import business.Editora;
import business.Jogo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Thiago
 */
public class DBManager {
    
    private DBWorker dbWorker;
    
    /**
     *
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws IllegalAccessException
     * @throws InstantiationException
     */
    public DBManager() throws SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
        dbWorker = new DBWorker("192.168.56.110", "admin", "123", "ludoteca");
    }
    
    
    //Métodos relacionados à Classe Autor:
    /**
     * Método que vai a bd em busca de todos os autores e guarda num arrayList
     * @return arrayList de Autor
     * @throws SQLException
     */
    public ArrayList<Autor> buscarTodosAutores() throws SQLException{
        ArrayList<Autor> arrayAutor = new ArrayList<>();
        Autor autor = null;
        String sql = "SELECT * from autor;";
        ResultSet resultado = dbWorker.executeQuery(sql);
        while (resultado.next()){
            autor = new Autor(resultado.getInt("id"), resultado.getString("nomeAutor"));
            arrayAutor.add(autor);
        }
        return arrayAutor;
    }
    
    /**
     * Método recebe um autor, e insere à bd se este ainda não existir.
     * @param autor
     * @return o número de linhas afetadas pela query INSERT
     * @throws SQLException
     */
    public int inserirAutor(Autor autor) throws SQLException{
        if (autor != null) {
            String sql = "INSERT INTO autor (id, nomeAutor) VALUES (NULL, '" + autor.getNomeAutor() + "');";
        
            return dbWorker.executeUpdate(sql);
        }   
        return 0;
    }
    
    /**
     * Método recebe o nome de um Autor, vai à bd e se existir retorna esse autor
     * @param nomeAutor
     * @return o autor procurado pelo nome
     * @throws SQLException
     */
    public Autor buscarAutor(String nomeAutor) throws SQLException{
        Autor autor = null;
        String sql = "SELECT * FROM autor WHERE nomeAutor = '" + nomeAutor + "';";
        
        ResultSet resultado = dbWorker.executeQuery(sql);
        if(resultado.next()){
            autor = new Autor(resultado.getInt("id"), resultado.getString("nomeAutor"));
        }
        
        return autor;
    }
    
    /**
     * Método que recebe um autor e tenta apagá-lo da bd.
     * @param autor
     * @return número de linhas afetadas pela query DELETE
     * @throws SQLException
     */
    public int removerAutor(Autor autor) throws SQLException{
        if(autor != null){
            String sql = "DELETE FROM autor WHERE nomeAutor = '" + autor.getNomeAutor() + "';";
            
            return dbWorker.executeUpdate(sql);
        }
        return 0;
    }
    
    public int alterarAutor(Autor autor, String novoNomeAutor) throws SQLException{
        String sql = "UPDATE autor SET nomeAutor = '" + novoNomeAutor + "' WHERE id = " + autor.getId() + ";";
            
        return dbWorker.executeUpdate(sql);
        
    }
    
   
    //Métodos relacionados à Classe Artista
    
    public ArrayList<Artista> buscarTodosArtistas() throws SQLException{
        ArrayList<Artista> arrayArtista = new ArrayList<>();
        Artista artista = null;
        String sql = "SELECT * from artista;";
        ResultSet resultado = dbWorker.executeQuery(sql);
        while (resultado.next()){
            artista = new Artista(resultado.getInt("id"), resultado.getString("nomeArtista"));
            arrayArtista.add(artista);
        }
        return arrayArtista;
    }
    
    public Artista buscarArtista(String nomeArtista) throws SQLException{
        Artista artista = null;
        String sql = "SELECT * FROM artista WHERE nomeArtista = '" + nomeArtista + "';";
        
        ResultSet resultado = dbWorker.executeQuery(sql);
        if(resultado.next()){
            artista = new Artista(resultado.getInt("id"), resultado.getString("nomeArtista"));
        }
        
        return artista;
    }
    
     public int inserirArtista(Artista artista) throws SQLException{
        if (artista != null) {
            String sql = "INSERT INTO artista (id, nomeArtista) VALUES (NULL, '" + artista.getNomeArtista() + "');";
        
            return dbWorker.executeUpdate(sql);
        }   
        return 0;
    }
    
     public int removerArtista(Artista artista) throws SQLException{
        if(artista != null){
            String sql = "DELETE FROM artista WHERE nomeArtista = '" + artista.getNomeArtista() + "';";
            
            return dbWorker.executeUpdate(sql);
        }
        return 0;
    }
     
     public int alterarArtista(Artista artista, String novoNomeArtista) throws SQLException{
        String sql = "UPDATE artista SET nomeArtista = '" + novoNomeArtista + "' WHERE id = " + artista.getId() + ";";
            
        return dbWorker.executeUpdate(sql);
        
    }
    
    //Métodos relacionados à Classe Editora
    
    public ArrayList<Editora> buscarTodasEditoras() throws SQLException{
        ArrayList<Editora> arrayEditora = new ArrayList<>();
        Editora editora = null;
        String sql = "SELECT * from editora;";
        ResultSet resultado = dbWorker.executeQuery(sql);
        while (resultado.next()){
            editora = new Editora(resultado.getInt("id"), resultado.getString("nomeEditora"));
            arrayEditora.add(editora);
        }
        return arrayEditora;
    }
    
    public Editora buscarEditora(String nomeEditora) throws SQLException{
        Editora editora = null;
        String sql = "SELECT * FROM editora WHERE nomeEditora = '" + nomeEditora + "';";
        
        ResultSet resultado = dbWorker.executeQuery(sql);
        if(resultado.next()){
            editora = new Editora(resultado.getInt("id"), resultado.getString("nomeEditora"));
        }
        
        return editora;
    }
    
     public int inserirEditora(Editora editora) throws SQLException{
        if (editora != null) {
            String sql = "INSERT INTO editora (id, nomeEditora) VALUES (NULL, '" + editora.getNomeEditora() + "');";
        
            return dbWorker.executeUpdate(sql);
        }   
        return 0;
    }
    
     public int removerEditora(Editora editora) throws SQLException{
        if(editora != null){
            String sql = "DELETE FROM editora WHERE nomeEditora = '" + editora.getNomeEditora() + "';";
            
            return dbWorker.executeUpdate(sql);
        }
        return 0;
    }
     
     public int alterarEditora(Editora editora, String novoNomeEditora) throws SQLException{
        String sql = "UPDATE editora SET nomeEditora = '" + novoNomeEditora + "' WHERE id = " + editora.getId() + ";";
            
        return dbWorker.executeUpdate(sql);
        
    }
     
     //Métodos relacionados à Classe Categoria
     
     public ArrayList<Categoria> buscarTodasCategorias() throws SQLException{
        ArrayList<Categoria> arrayCategoria = new ArrayList<>();
        Categoria categoria = null;
        String sql = "SELECT * from categoria;";
        ResultSet resultado = dbWorker.executeQuery(sql);
        while (resultado.next()){
            categoria = new Categoria(resultado.getInt("id"), resultado.getString("nomecategoria"));
            arrayCategoria.add(categoria);
        }
        return arrayCategoria;
    }
     
    public Categoria buscarCategoria(String nomeCategoria) throws SQLException{
        Categoria categoria = null;
        String sql = "SELECT * FROM categoria WHERE nomeCategoria = '" + nomeCategoria + "';";
        
        ResultSet resultado = dbWorker.executeQuery(sql);
        if(resultado.next()){
            categoria = new Categoria(resultado.getInt("id"), resultado.getString("nomeCategoria"));
        }
        
        return categoria;
    }
    
     public int inserirCategoria(Categoria categoria) throws SQLException{
        if (categoria != null) {
            String sql = "INSERT INTO categoria (id, nomecategoria) VALUES (NULL, '" + categoria.getNomeCategoria() + "');";
        
            return dbWorker.executeUpdate(sql);
        }   
        return 0;
    }
    
     public int removerCategoria(Categoria categoria) throws SQLException{
        if(categoria != null){
            String sql = "DELETE FROM categoria WHERE nomecategoria = '" + categoria.getNomeCategoria() + "';";
            
            return dbWorker.executeUpdate(sql);
        }
        return 0;
    }
     
     public int alterarCategoria(Categoria categoria, String novoNomeCategoria) throws SQLException{
        String sql = "UPDATE categoria SET nomeCategoria = '" + novoNomeCategoria + "' WHERE id = " + categoria.getId() + ";";
            
        return dbWorker.executeUpdate(sql);
        
    } 
     
     
    //Métodos relacionados à Classe Jogo
    
    public Jogo buscarJogo(String nomeJogo) throws SQLException{
        Jogo jogo = null;
        String sql = "SELECT * FROM jogo WHERE nomeJogo = '" + nomeJogo + "';";
        
        ResultSet resultado = dbWorker.executeQuery(sql);
        if(resultado.next()){
            jogo = new Jogo(resultado.getInt("id"), resultado.getString("nomeJogo"), resultado.getString("imagem"), resultado.getDouble("precoCompra"));
        }
        
        return jogo;
    }
    
    public ArrayList<Jogo> buscarTodosJogos() throws SQLException{
        ArrayList<Jogo> arrayJogo = new ArrayList<>();
        Jogo jogo = null;
        String sql = "SELECT * from jogo;";
        ResultSet resultado = dbWorker.executeQuery(sql);
        while (resultado.next()){
            jogo = new Jogo(resultado.getInt("id"), resultado.getString("nomeJogo"), resultado.getString("imagem"));
            arrayJogo.add(jogo);
        }
        return arrayJogo;
    }
    
    public int removerJogo(Jogo jogo) throws SQLException{
        if(jogo != null){
            String sql = "DELETE FROM jogo WHERE nomejogo = '" + jogo.getNome() + "';";
            String sql1 = "DELETE FROM jogoCategoria WHERE codJogo = '" + jogo.getId()+ "';";
            
            dbWorker.executeUpdate(sql1);
            return dbWorker.executeUpdate(sql);
        }
        return 0;
    }
    
    public int inserirJogo(Jogo jogo) throws SQLException{
        if (jogo != null) {
            String sql = String.format("INSERT INTO jogo (id, nomeJogo, codAutor, codArtista, codEditora, numJogadorMin, numJogadorMax, dataLancamento, descricao, "
                    + "qtdCopias, precoCompra) VALUES (NULL, '%s', %s, %s, %s, %s, %s, %s, '%s', %s, %s);", jogo.getNome(), jogo.getCodAutor(), jogo.getCodArtista(), jogo.getCodEditora(), jogo.getNumJogadorMin(), 
                    jogo.getNumJogadorMax(), jogo.getDataLancamento(), jogo.getDescricao(), jogo.getQtdCopias(), jogo.getPrecoCompra());
        
            return dbWorker.executeUpdate(sql);
        }   
        return 0;
    }
    
     public int alterarJogo(Jogo jogo, String novoNomeJogo, int novoAutor, int novoArtista, int novaEditora, int novoNumMin, int novoNumMax, int novaData, String novaDescricao, int novaQtdCopias, double novoPreco) throws SQLException{
        String sql = String.format("UPDATE jogo SET nomeJogo = '%s', codAutor = %s, codArtista = %s, codEditora = %s, numJogadorMin = %s, numJogadorMax = %s, dataLancamento = %s, "
                + "descricao = '%s', qtdCopias = %s, precoCompra = %s WHERE id = %s;", novoNomeJogo, novoAutor, novoArtista, novaEditora, novoNumMin, novoNumMax, novaData, novaDescricao, novaQtdCopias, novoPreco, jogo.getId());
            System.out.println(sql);
        return dbWorker.executeUpdate(sql);
        
    } 
    
}
