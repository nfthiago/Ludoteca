/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package presentation;

import business.Artista;
import business.Autor;
import business.Editora;
import business.Jogo;
import business.ResultSetTableModel;
import java.awt.Image;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import persistence.DBManager;
import persistence.DBWorker;

/**
 *
 * @author Thiago
 */
public class Starter extends javax.swing.JFrame {
    
    private void styleTabela(){
        tblJogos.getColumnModel().getColumn(0).setPreferredWidth(180);
        tblJogos.getColumnModel().getColumn(1).setPreferredWidth(50);
        tblJogos.getColumnModel().getColumn(2).setPreferredWidth(50);
        tblJogos.getColumnModel().getColumn(3).setPreferredWidth(50);
        tblJogos.getColumnModel().getColumn(4).setPreferredWidth(5);
        tblJogos.getColumnModel().getColumn(5).setPreferredWidth(5);
        tblJogos.getColumnModel().getColumn(6).setPreferredWidth(6);
        tblJogos.getColumnModel().getColumn(7).setPreferredWidth(200);
        tblJogos.getColumnModel().getColumn(8).setPreferredWidth(5);
        
        JTableHeader header= tblJogos.getTableHeader();
        TableColumnModel colMod = header.getColumnModel();
        TableColumn jogos = colMod.getColumn(0);
        jogos.setHeaderValue("Board Games");
        TableColumn autores = colMod.getColumn(1);
        autores.setHeaderValue("Game Designers");
        autores.setMinWidth(75);
        TableColumn artistas = colMod.getColumn(2);
        artistas.setHeaderValue("Artistas");
        artistas.setMinWidth(65);
         TableColumn editoras = colMod.getColumn(3);
        editoras.setHeaderValue("Editoras");
        editoras.setMinWidth(75);
        TableColumn numMin = colMod.getColumn(4);
        numMin.setHeaderValue("Min.");
        numMin.setMinWidth(5);
        TableColumn numMax = colMod.getColumn(5);
        numMax.setHeaderValue("Max.");
        numMax.setMinWidth(8);
        TableColumn data = colMod.getColumn(6);
        data.setHeaderValue("Ano");
        data.setMinWidth(6);
        TableColumn descricao = colMod.getColumn(7);
        descricao.setHeaderValue("Descrição");
        descricao.setMinWidth(200);
        TableColumn copias = colMod.getColumn(8);
        copias.setHeaderValue("Cópias");
        copias.setMinWidth(10);
        
        
        
        header.repaint();
        
    }
    
    private void carregaTabela(String sql){
        try {
            DBWorker dbWorker = new DBWorker("192.168.56.110", "admin", "123", "ludoteca");
            ResultSet rs = dbWorker.executeQuery(sql);
            ResultSetTableModel rsTbl = new ResultSetTableModel(rs);
            tblJogos.setModel(rsTbl);
            
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    
    private void carregaComboAutor(){
        cbbAutor.removeAllItems();
        //Instanciando de DBManager
            DBManager dbManager;
        try {
            dbManager = new DBManager();
            //Instanciando um ArrayList de Autor
            ArrayList<Autor> arrayAutores = new ArrayList<>();
            
            //Guardando o resultado do método (array de autores) no objeto arrayAutores
            arrayAutores = dbManager.buscarTodosAutores();
            
//            //Instanciando classe para criar um modelo de lista
//            DefaultListModel list = new DefaultListModel();
            
            cbbAutor.addItem("Todos");
            
            for (Autor arrayAutor : arrayAutores){
                cbbAutor.addItem(arrayAutor.getNomeAutor());
            }
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }

    private void carregaComboArtista(){
        cbbArtista.removeAllItems();
        //Instanciando de DBManager
            DBManager dbManager;
        try {
            dbManager = new DBManager();
            //Instanciando um ArrayList de Artista
            ArrayList<Artista> arrayArtistas = new ArrayList<>();
            
            //Guardando o resultado do método (array de Artistas) no objeto arrayArtistas
            arrayArtistas = dbManager.buscarTodosArtistas();
            
            //Instanciando classe para criar um modelo de lista
//            DefaultListModel list = new DefaultListModel();
            
            cbbArtista.addItem("Todos");
            
            for (Artista arrayArtista : arrayArtistas){
                cbbArtista.addItem(arrayArtista.getNomeArtista());
            }
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
    
    private void carregaComboEditora(){
        cbbEditora.removeAllItems();
        //Instanciando de DBManager
            DBManager dbManager;
        try {
            dbManager = new DBManager();
            //Instanciando um ArrayList de Editora
            ArrayList<Editora> arrayEditoras = new ArrayList<>();
            
            //Guardando o resultado do método (array de Editoras) no objeto arrayEditoras
            arrayEditoras = dbManager.buscarTodasEditoras();
            
            //Instanciando classe para criar um modelo de lista
//            DefaultListModel list = new DefaultListModel();
            
            cbbEditora.addItem("Todos");
            
            for (Editora arrayEditora : arrayEditoras){
                cbbEditora.addItem(arrayEditora.getNomeEditora());
            }
        } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
    /**
     * Creates new form Starter
     */
    public Starter() {
        initComponents();
        
                             
        ImageIcon imgPstat = new ImageIcon("src/support/StarterLudopedia.png");
        
        //Redimensionar imagens
        Image image = imgPstat.getImage();
        Image image2 = image.getScaledInstance(1000, 150, java.awt.Image.SCALE_SMOOTH);
        ImageIcon finalImage = new ImageIcon(image2);
        lblCidadeCuriosa.setIcon(finalImage);
        
        String sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin AS 'Min', J.numJogadorMax AS 'Max', J.dataLancamento AS 'Ano',J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";
        
        carregaTabela(sql);
        styleTabela();
        carregaComboAutor();
        carregaComboArtista();
        carregaComboEditora();
        
        
        tblJogos.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(tblJogos.getSelectedRow() > -1){
                    mnuBarEditJogo.setEnabled(true);
                    btnEditaJogo.setEnabled(true);
                    btnDeletaJogo.setEnabled(true);
                } else {
                    mnuBarEditJogo.setEnabled(false);
                    btnEditaJogo.setEnabled(false);
                    btnDeletaJogo.setEnabled(false);
                }
                            }
        });
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblJogos = new javax.swing.JTable();
        lblCidadeCuriosa = new javax.swing.JLabel();
        cbbAutor = new javax.swing.JComboBox<>();
        cbbArtista = new javax.swing.JComboBox<>();
        cbbEditora = new javax.swing.JComboBox<>();
        lblAutor = new javax.swing.JLabel();
        lblArtista = new javax.swing.JLabel();
        lblEditora = new javax.swing.JLabel();
        btnFiltrar = new javax.swing.JButton();
        btnDeletaJogo = new javax.swing.JButton();
        btnEditaJogo = new javax.swing.JButton();
        mnuBar = new javax.swing.JMenuBar();
        mnuBarFile = new javax.swing.JMenu();
        mnuBarEdit = new javax.swing.JMenu();
        mnuBarEditEditora = new javax.swing.JMenuItem();
        mnuBarEditArtista = new javax.swing.JMenuItem();
        mnuBarEditAutor = new javax.swing.JMenuItem();
        mnuBarEditCategoria = new javax.swing.JMenuItem();
        mnuBarEditJogo = new javax.swing.JMenuItem();
        mnuBarInsert = new javax.swing.JMenu();
        mnuBarInsertJogo = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblJogos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblJogos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblJogosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblJogos);

        lblCidadeCuriosa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/support/StarterLudopedia.png"))); // NOI18N

        lblAutor.setText("Game designers:");

        lblArtista.setText("Artistas:");

        lblEditora.setText("Editoras:");

        btnFiltrar.setText("Filtrar");
        btnFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltrarActionPerformed(evt);
            }
        });

        btnDeletaJogo.setText("Remover");
        btnDeletaJogo.setEnabled(false);
        btnDeletaJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletaJogoActionPerformed(evt);
            }
        });

        btnEditaJogo.setText("Editar");
        btnEditaJogo.setEnabled(false);
        btnEditaJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditaJogoActionPerformed(evt);
            }
        });

        mnuBarFile.setText("File");
        mnuBar.add(mnuBarFile);

        mnuBarEdit.setText("Editar");

        mnuBarEditEditora.setText("Editora");
        mnuBarEditEditora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarEditEditoraActionPerformed(evt);
            }
        });
        mnuBarEdit.add(mnuBarEditEditora);

        mnuBarEditArtista.setText("Artista");
        mnuBarEditArtista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarEditArtistaActionPerformed(evt);
            }
        });
        mnuBarEdit.add(mnuBarEditArtista);

        mnuBarEditAutor.setText("Designer");
        mnuBarEditAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarEditAutorActionPerformed(evt);
            }
        });
        mnuBarEdit.add(mnuBarEditAutor);

        mnuBarEditCategoria.setText("Categoria");
        mnuBarEditCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarEditCategoriaActionPerformed(evt);
            }
        });
        mnuBarEdit.add(mnuBarEditCategoria);

        mnuBarEditJogo.setText("Jogo");
        mnuBarEditJogo.setEnabled(false);
        mnuBarEditJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarEditJogoActionPerformed(evt);
            }
        });
        mnuBarEdit.add(mnuBarEditJogo);

        mnuBar.add(mnuBarEdit);

        mnuBarInsert.setText("Inserir");

        mnuBarInsertJogo.setText("Jogo");
        mnuBarInsertJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuBarInsertJogoActionPerformed(evt);
            }
        });
        mnuBarInsert.add(mnuBarInsertJogo);

        mnuBar.add(mnuBarInsert);

        setJMenuBar(mnuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblCidadeCuriosa, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAutor)
                            .addComponent(cbbAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblArtista)
                                .addGap(120, 120, 120))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(cbbArtista, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbbEditora, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblEditora)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnEditaJogo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDeletaJogo)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(lblCidadeCuriosa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblEditora)
                            .addComponent(lblArtista))
                        .addGap(0, 2, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblAutor)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbEditora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFiltrar)
                    .addComponent(cbbArtista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeletaJogo)
                    .addComponent(btnEditaJogo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuBarInsertJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarInsertJogoActionPerformed
       InsertJogo insertJogo = new InsertJogo(this, rootPaneCheckingEnabled);
       insertJogo.setVisible(rootPaneCheckingEnabled);
       String sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin AS 'Min', J.numJogadorMax AS 'Max', J.dataLancamento AS 'Ano',J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";
        
        carregaTabela(sql);
        styleTabela();
       
                
    }//GEN-LAST:event_mnuBarInsertJogoActionPerformed

    private void mnuBarEditAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarEditAutorActionPerformed
       EditAutor editAutor = new EditAutor(this, rootPaneCheckingEnabled);
       editAutor.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuBarEditAutorActionPerformed

    private void mnuBarEditEditoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarEditEditoraActionPerformed
        EditEditora editEditora = new EditEditora(this, rootPaneCheckingEnabled);
        editEditora.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuBarEditEditoraActionPerformed

    private void mnuBarEditArtistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarEditArtistaActionPerformed
        EditArtista editArtista = new EditArtista(this, rootPaneCheckingEnabled);
        editArtista.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuBarEditArtistaActionPerformed

    private void mnuBarEditCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarEditCategoriaActionPerformed
        EditCategoria editCategoria = new EditCategoria(this, rootPaneCheckingEnabled);
        editCategoria.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuBarEditCategoriaActionPerformed

    private void btnFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltrarActionPerformed
       String nomeAutor;
       String nomeArtista;
       String nomeEditora;
       String sql;
       int codAutor = 0;
       int codArtista = 0;
       int codEditora = 0;
       
       nomeAutor = cbbAutor.getModel().getSelectedItem().toString();
       nomeArtista = cbbArtista.getModel().getSelectedItem().toString();
       nomeEditora = cbbEditora.getModel().getSelectedItem().toString();
       
       if(nomeAutor.equals("Todos") && !nomeArtista.equals("Todos") && !nomeEditora.equals("Todos")){
           
            DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codArtista = dbManager.buscarArtista(nomeArtista).getId();
                 codEditora = dbManager.buscarEditora(nomeEditora).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }



             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codArtista = %s AND J.codEditora = %s;", codArtista, codEditora);   

             carregaTabela(sql);
             styleTabela();
             
       }else if (nomeAutor.equals("Todos") && nomeArtista.equals("Todos") && !nomeEditora.equals("Todos")){
           DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codEditora = dbManager.buscarEditora(nomeEditora).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }



             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codEditora = %s;", codEditora);   

             carregaTabela(sql);
             styleTabela();
             
    }  else if   (nomeAutor.equals("Todos") && !nomeArtista.equals("Todos") && nomeEditora.equals("Todos")){
           DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codArtista = dbManager.buscarArtista(nomeArtista).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }



             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codArtista = %s;", codArtista);   

             carregaTabela(sql);
             styleTabela();
             
    } else if(!nomeAutor.equals("Todos") && nomeArtista.equals("Todos") && !nomeEditora.equals("Todos")){
           
            DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codAutor = dbManager.buscarAutor(nomeAutor).getId();
                 codEditora = dbManager.buscarEditora(nomeEditora).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }

             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codAutor = %s AND J.codEditora = %s;", codAutor, codEditora);   

             carregaTabela(sql);
             styleTabela();
             
    } else if (!nomeAutor.equals("Todos") && nomeArtista.equals("Todos") && nomeEditora.equals("Todos")){
           DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codAutor = dbManager.buscarAutor(nomeAutor).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }


             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codAutor = %s;", codAutor);   

             carregaTabela(sql);
             styleTabela();
             
    } else if(!nomeAutor.equals("Todos") && !nomeArtista.equals("Todos") && nomeEditora.equals("Todos")){
           
            DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 codAutor = dbManager.buscarAutor(nomeAutor).getId();
                 codArtista = dbManager.buscarArtista(nomeArtista).getId();
                 

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }



             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codAutor = %s AND J.codArtista = %s;", codAutor, codArtista);   

             carregaTabela(sql);
             styleTabela();
             
       } else if(!nomeAutor.equals("Todos") && !nomeArtista.equals("Todos") && !nomeEditora.equals("Todos")){
           
            DBManager dbManager;
             try {
                 dbManager = new DBManager();
                 
                 codAutor = dbManager.buscarAutor(nomeAutor).getId();
                 codArtista = dbManager.buscarArtista(nomeArtista).getId();
                 codEditora = dbManager.buscarEditora(nomeEditora).getId();

             } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                 Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
             }



             sql = String.format("SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                     + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                     + "INNER JOIN editora E ON J.codEditora = E.id WHERE J.codAutor = %s AND J.codArtista = %s AND J.codEditora = %s;", codAutor, codArtista, codEditora);   

             carregaTabela(sql);
             styleTabela();
             
       } else if(nomeAutor.equals("Todos") && nomeArtista.equals("Todos") && nomeEditora.equals("Todos")){
           
            sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";   

             carregaTabela(sql);
             styleTabela();
             
       } 
    }//GEN-LAST:event_btnFiltrarActionPerformed

    private void tblJogosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblJogosMouseClicked
       btnEditaJogo.setEnabled(true);
       btnDeletaJogo.setEnabled(true);
    }//GEN-LAST:event_tblJogosMouseClicked

    private void btnDeletaJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletaJogoActionPerformed
       int linha;
       String nomeJogo;
       linha = tblJogos.getSelectedRow();
       nomeJogo = (String) tblJogos.getValueAt(linha, 0);
       String mensagem = "Tem certeza de que quer remover o jogo " + nomeJogo + "?";
       
       if(JOptionPane.showConfirmDialog(rootPane, mensagem, "Janela de confirmação", JOptionPane.YES_NO_OPTION) == 0){
            
            try {
                DBManager dbManager = new DBManager();
                Jogo jogo = new Jogo();
                jogo = dbManager.buscarJogo(nomeJogo);
                if(dbManager.removerJogo(jogo) != 0){
                    JOptionPane.showMessageDialog(rootPane, "Jogo removido com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    String sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin, J.numJogadorMax, J.dataLancamento ,J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";
                carregaTabela(sql);
                carregaComboArtista();
                carregaComboAutor();
                carregaComboEditora();
                styleTabela();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Erro! Jogo não removido.", "Janela de erro", JOptionPane.ERROR_MESSAGE);
                }
              
              
            } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                Logger.getLogger(Starter.class.getName()).log(Level.SEVERE, null, ex);
            }
            
       btnEditaJogo.setEnabled(false);
       btnDeletaJogo.setEnabled(false);
       String sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin AS 'Min', J.numJogadorMax AS 'Max', J.dataLancamento AS 'Ano',J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";
       carregaTabela(sql);
       styleTabela();
       
        }
    }//GEN-LAST:event_btnDeletaJogoActionPerformed

    private void btnEditaJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditaJogoActionPerformed
       EditJogo editJogo = new EditJogo(this, rootPaneCheckingEnabled, tblJogos);
       editJogo.setVisible(rootPaneCheckingEnabled);
       editJogo.preencherCampos(tblJogos);
       String sql = "SELECT J.nomeJogo, AU.nomeAutor, AR.nomeArtista, E.nomeEditora, J.numJogadorMin AS 'Min', J.numJogadorMax AS 'Max', J.dataLancamento AS 'Ano',J.descricao, J.qtdCopias "
                    + "FROM jogo J INNER JOIN autor AU ON J.codAutor = AU.id INNER JOIN artista AR ON J.codArtista = AR.id "
                    + "INNER JOIN editora E ON J.codEditora = E.id;";
       carregaTabela(sql);
       styleTabela();
       
       
    }//GEN-LAST:event_btnEditaJogoActionPerformed

    private void mnuBarEditJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuBarEditJogoActionPerformed
       
       EditJogo editJogo = new EditJogo(this, rootPaneCheckingEnabled, tblJogos);
       editJogo.setVisible(rootPaneCheckingEnabled);
       editJogo.preencherCampos(tblJogos);
       
       
    }//GEN-LAST:event_mnuBarEditJogoActionPerformed

    
    /*
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Starter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Starter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Starter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Starter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Starter().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeletaJogo;
    private javax.swing.JButton btnEditaJogo;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JComboBox<String> cbbArtista;
    private javax.swing.JComboBox<String> cbbAutor;
    private javax.swing.JComboBox<String> cbbEditora;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblArtista;
    private javax.swing.JLabel lblAutor;
    private javax.swing.JLabel lblCidadeCuriosa;
    private javax.swing.JLabel lblEditora;
    private javax.swing.JMenuBar mnuBar;
    private javax.swing.JMenu mnuBarEdit;
    private javax.swing.JMenuItem mnuBarEditArtista;
    private javax.swing.JMenuItem mnuBarEditAutor;
    private javax.swing.JMenuItem mnuBarEditCategoria;
    private javax.swing.JMenuItem mnuBarEditEditora;
    private javax.swing.JMenuItem mnuBarEditJogo;
    private javax.swing.JMenu mnuBarFile;
    private javax.swing.JMenu mnuBarInsert;
    private javax.swing.JMenuItem mnuBarInsertJogo;
    private javax.swing.JTable tblJogos;
    // End of variables declaration//GEN-END:variables
}
