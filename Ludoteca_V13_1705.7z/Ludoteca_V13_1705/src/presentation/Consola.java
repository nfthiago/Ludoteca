/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentation;


import business.Autor;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import persistence.DBManager;
import persistence.DBWorker;

/**
 *
 * @author Thiago
 */
public class Consola {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        int opt = 0;
        
        do {            
            System.out.println("Bem-vindo a Ludoteca da Estufa!\n"
                    + "Escolha uma das seguintes opções: \n"
                    + "'1' - Para inserir um Autor \n"
                    + "'2' - Para remover um Autor \n"
                    + "'9' - Para sair do programa \n");
            try {
                opt = sc.nextInt();
                
            } catch (InputMismatchException e) {
                System.out.println("Opção incorreta!\n\n");
            } finally {
                sc.nextLine();
            }
            
            switch (opt) {
                case 1:
                {
                    try {
                        DBManager dbManager = new DBManager();
                        System.out.println("Opção 1 escolhida\n"
                                + "Diga o nome do autor para inseri-lo na base de dados");
                        String nomeAutor = sc.nextLine();
                        Autor autor = new Autor(nomeAutor);
                        int retorno = 0;
                        retorno = dbManager.inserirAutor(autor);
                        if(retorno == 0){
                            System.out.println("Erro ao inserir o autor!\n");
                        } else {
                            System.out.println("Autor inserido com sucesso!\n");
                        }
                        
                    } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                        Logger.getLogger(Consola.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                    break;
                    
                case 2:
                {
                try {
                    System.out.println("Opção 2 escolhida\n"
                            + "Diga o nome do autor para removê-lo da base de dados");
                    String nomeAutor = sc.nextLine();
                    Autor autor = new Autor(nomeAutor);
                    DBManager dbManager = new DBManager();
                    int retorno = 0;
                    retorno = dbManager.removerAutor(autor);
                    if(retorno == 0){
                        System.out.println("Autor não encontrado! Nada foi removido.\n");
                    } else {
                        System.out.println("Autor encontrado e removido com sucesso!\n");
                    }
                    
                } catch (SQLException | ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
                    Logger.getLogger(Consola.class.getName()).log(Level.SEVERE, null, ex);
                }
                    
                }
                    break;
                
                case 3:{
                    
                }
                    break;

                default:
                    throw new AssertionError();
            }
            
        } while (opt !=9);
        
    }
    
}
